#include "LoggerCore.h"
#include <math.h>    // sqrtf, lroundf
#include <stdio.h>   // snprintf
#include <string.h>  // memcpy, memset

// =============================================================================
// DEBUG MACROS
// =============================================================================
//
// NOTE: Kept identical in behavior. Formatting adjusted for readability.

#if VERBOSE_LOG
#define DBG_PRINT(x) Serial.print(x)
#define DBG_PRINTLN(x) Serial.println(x)
#else
#define DBG_PRINT(x) \
  do { \
  } while (0)
#define DBG_PRINTLN(x) \
  do { \
  } while (0)
#endif

// =============================================================================
// CONFIG / CONSTANTS
// =============================================================================

// IMU and Flash pins (XIAO nRF52840)
const uint8_t PIN_IMU_CS = D5;
const uint8_t PIN_FLASH_CS = D2;

const uint32_t DEFAULT_PAGES_TO_LOG = 10;

// =============================================================================
// GLOBAL OBJECTS
// =============================================================================

// IMU / Flash
ICM_20948_SPI myICM;
SPIFlash flash(PIN_FLASH_CS);

uint32_t flashCapacityBytes = 0;
uint32_t flashTotalPages = 0;
uint32_t flashRecordPages = 0;

// Playback / mode
PlaybackFormat playbackFormat = PLAYBACK_ASCII;
RunMode mode = MODE_IDLE;

// Recording state
uint32_t pageStartMs = 0;
uint32_t pageFirstID = 0;
uint32_t recordPageLimit = 0;
uint32_t recordStartPage = 0;
uint32_t frameCounter = 0;

Frame20 pageFrames[FRAMES_PER_PAGE];
uint16_t frameIndexInPage = 0;
uint32_t currentPage = 0;

// Playback state
uint32_t playbackPage = 0;
uint16_t playbackFrameIndex = 0;
bool playbackPageLoaded = false;

uint32_t playbackPagesSeen = 0;
uint32_t playbackCrcWarnings = 0;

uint8_t playbackPageBuf[FLASH_PAGE_SIZE];
Frame20 *playbackFrames = reinterpret_cast<Frame20 *>(playbackPageBuf);
PageFooter playbackFooter;

uint32_t playbackPageLimit = 0;

// Boot scan diagnostics
uint32_t bootPagesFound = 0;
uint32_t bootValidPages = 0;
uint32_t bootCorruptPages = 0;

// Command buffer (owned by core; filled by .ino input loop)
char cmdBuf[CMD_BUF_SIZE];
uint16_t cmdLen = 0;

// =============================================================================
// OUTPUT HELPERS
// =============================================================================
//
// NOTE: These remain here because they are used across subsystems (Core, BLE, CLI).
// No behavioral changes.

void emitControl(void (*fn)(Stream &)) {
  fn(Serial);

  if (bleUartEnabled && bleConnected) {
    fn(bleuart);
  }
}

void emitEvent(const char *msg) {
  Serial.println(msg);

  if (bleUartEnabled && bleConnected && bleuart.notifyEnabled()) {
    bleuart.println(msg);
  }
}

// =============================================================================
// UTILITIES
// =============================================================================

int16_t floatToQ15(float x) {
  if (x > 1.0f) x = 1.0f;
  if (x < -1.0f) x = -1.0f;

  long v = (long)lroundf(x * 32767.0f);
  if (v > 32767) v = 32767;
  if (v < -32768) v = -32768;

  return (int16_t)v;
}

uint16_t crc16_ccitt(const uint8_t *data, size_t len) {
  uint16_t crc = 0xFFFF;

  while (len--) {
    crc ^= (uint16_t)(*data++) << 8;

    for (int i = 0; i < 8; i++) {
      crc = (crc & 0x8000) ? (uint16_t)((crc << 1) ^ 0x1021)
                           : (uint16_t)(crc << 1);
    }
  }

  return crc;
}

void getMCUSerialString(char *out, size_t outLen) {
  uint32_t id0 = NRF_FICR->DEVICEID[0];
  uint32_t id1 = NRF_FICR->DEVICEID[1];

  snprintf(out, outLen, "%08lX%08lX",
           (unsigned long)id1,
           (unsigned long)id0);
}

// =============================================================================
// RESERVED TAIL STORAGE (256 x 256-byte elements)
// =============================================================================
//
// Storage lives in the last FLASH_RESERVED_PAGES pages of the chip.
// These pages are excluded from motion logging and boot-time page scanning.
//
// NOTE:
//  - Writes are sector-granular (4 KB). To preserve adjacent elements, we
//    read-modify-erase-rewrite the containing sector.

static uint32_t storageBasePage() {
  if (flashTotalPages < FLASH_RESERVED_PAGES) {
    return 0;
  }
  return flashTotalPages - FLASH_RESERVED_PAGES;
}

static uint32_t storagePageForIndex(uint16_t index) {
  return storageBasePage() + (uint32_t)index;
}

bool readStorageElement(uint16_t index, uint8_t *out256) {
  if (!out256 || index >= FLASH_RESERVED_PAGES) {
    return false;
  }

  const uint32_t page = storagePageForIndex(index);
  const uint32_t addr = page * FLASH_PAGE_SIZE;
  return flash.readData(addr, out256, FLASH_PAGE_SIZE);
}

bool writeStorageElement(uint16_t index, const uint8_t *in256) {
  if (!in256 || index >= FLASH_RESERVED_PAGES) {
    return false;
  }

  const uint32_t pageAddr = storagePageForIndex(index) * FLASH_PAGE_SIZE;
  const uint32_t sectorAddr = pageAddr & ~(uint32_t)(FLASH_SECTOR_SIZE - 1);
  const uint32_t pageOffset = pageAddr - sectorAddr;

  uint8_t sectorBuf[FLASH_SECTOR_SIZE];
  if (!flash.readData(sectorAddr, sectorBuf, FLASH_SECTOR_SIZE)) {
    return false;
  }

  memcpy(sectorBuf + pageOffset, in256, FLASH_PAGE_SIZE);

  if (!flash.eraseSector(sectorAddr)) {
    return false;
  }

  for (uint32_t off = 0; off < FLASH_SECTOR_SIZE; off += FLASH_PAGE_SIZE) {
    if (!flash.writePage(sectorAddr + off, sectorBuf + off, FLASH_PAGE_SIZE)) {
      return false;
    }
  }

  return true;
}


// =============================================================================
// DEVICE IDENTIFICATION
// =============================================================================

void printFirmwareVersion(Stream &out) {
  out.print("Firmware version: ");
  out.println(FW_VERSION);
}

void printMCUDeviceID(Stream &out) {
  uint32_t id0 = NRF_FICR->DEVICEID[0];
  uint32_t id1 = NRF_FICR->DEVICEID[1];

  out.print("MCU Device ID: 0x");
  out.print(id1, HEX);
  out.println(id0, HEX);
}

void printIMUDeviceID(Stream &out) {
  uint8_t whoami = 0;

  SPI.beginTransaction(SPISettings(7000000, MSBFIRST, SPI_MODE3));

  // Select USER BANK 0
  digitalWrite(PIN_IMU_CS, LOW);
  delayMicroseconds(1);
  SPI.transfer(0x7F & 0x7F);  // REG_BANK_SEL (write)
  SPI.transfer(0x00);         // Bank 0
  digitalWrite(PIN_IMU_CS, HIGH);

  delayMicroseconds(1);

  // Read WHO_AM_I (0x00)
  digitalWrite(PIN_IMU_CS, LOW);
  delayMicroseconds(1);
  SPI.transfer(0x80 | 0x00);  // Read WHO_AM_I
  whoami = SPI.transfer(0x00);
  digitalWrite(PIN_IMU_CS, HIGH);

  SPI.endTransaction();

  out.print("IMU WHO_AM_I: 0x");
  out.print(whoami, HEX);

  if (whoami == 0xEA) {
    out.println(" (ICM-20948)");
  } else {
    out.println(" (unexpected)");
  }
}

// =============================================================================
// FLASH BOOT SCAN
// =============================================================================

void scanFlashOnBoot() {
  bootPagesFound = 0;
  bootValidPages = 0;
  bootCorruptPages = 0;

  uint8_t pageBuf[FLASH_PAGE_SIZE];

  for (uint32_t page = 0; page < flashRecordPages; page++) {

    const uint32_t addr = page * FLASH_PAGE_SIZE;
    if (!flash.readData(addr, pageBuf, FLASH_PAGE_SIZE)) {
      break;
    }

    const uint16_t footerOffset = FLASH_PAGE_SIZE - sizeof(PageFooter);

    PageFooter footer;
    memcpy(&footer, pageBuf + footerOffset, sizeof(PageFooter));

    if (footer.magic != PAGE_MAGIC) {
      break;
    }

    bootPagesFound++;

    const bool footerSane = (footer.validFrames <= FRAMES_PER_PAGE);
    bool crcOk = false;

    if (footerSane) {
      const uint16_t usedBytes = footer.validFrames * sizeof(Frame20);
      const uint16_t crcLen = usedBytes + offsetof(PageFooter, crc16);

      crcOk = (crc16_ccitt(pageBuf, crcLen) == footer.crc16);
    }

    if (footerSane && crcOk) {
      bootValidPages++;
    } else {
      bootCorruptPages++;
    }
  }

  currentPage = bootPagesFound;
}

void reconstructFrameCounterFromFlash() {
  if (currentPage == 0) {
    frameCounter = 0;
    return;
  }

  const uint32_t addr =
    (currentPage - 1) * FLASH_PAGE_SIZE + FLASH_PAGE_SIZE - sizeof(PageFooter);

  PageFooter footer;
  if (!flash.readData(addr, (uint8_t *)&footer, sizeof(PageFooter))) {
    frameCounter = 0;
    return;
  }

  if (footer.magic != PAGE_MAGIC || footer.validFrames > FRAMES_PER_PAGE) {
    frameCounter = 0;
    return;
  }

  frameCounter = footer.firstFrameID + footer.validFrames;
}

// =============================================================================
// FLASH LOGGING
// =============================================================================

void flushPageToFlash() {

  if (recordPageLimit > 0 && (currentPage - recordStartPage) >= recordPageLimit) {
    return;
  }

  if (currentPage >= flashRecordPages) {
    emitEvent("# Flash full — recording stopped");
    mode = MODE_IDLE;
    return;
  }

  const uint32_t addr = currentPage * FLASH_PAGE_SIZE;

  uint8_t rawPage[FLASH_PAGE_SIZE];

  const uint16_t usedBytes = FRAMES_PER_PAGE * sizeof(Frame20);
  memcpy(rawPage, pageFrames, usedBytes);

  const uint16_t footerOffset = FLASH_PAGE_SIZE - sizeof(PageFooter);
  memset(rawPage + usedBytes, 0xFF, footerOffset - usedBytes);

  PageFooter footer;
  footer.magic = PAGE_MAGIC;
  footer.validFrames = frameIndexInPage;
  footer.crc16 = 0;
  footer.firstFrameID = pageFirstID;
  footer.pageStartMs = pageStartMs;

  memcpy(rawPage + footerOffset, &footer, sizeof(PageFooter));

  const uint16_t crcLen = usedBytes + offsetof(PageFooter, crc16);
  ((PageFooter *)(rawPage + footerOffset))->crc16 = crc16_ccitt(rawPage, crcLen);

  flash.writePage(addr, rawPage, FLASH_PAGE_SIZE);

  frameIndexInPage = 0;
  currentPage++;
}

bool logFrame(const Frame20 &f) {
  if (mode != MODE_RECORDING) {
    return false;
  }

  if (recordPageLimit > 0 && frameIndexInPage == 0 && (currentPage - recordStartPage) >= recordPageLimit) {

    emitEvent("# Recording page limit reached");
    mode = MODE_IDLE;
    printPrompt();
    return false;
  }

  pageFrames[frameIndexInPage++] = f;

  if (frameIndexInPage >= FRAMES_PER_PAGE) {
    flushPageToFlash();
  }

  return true;
}

// =============================================================================
// PLAYBACK
// =============================================================================
//
// NOTE: Kept behavior identical. Minor clarity improvements only.
// Structural issue to discuss (not implemented): CRC check currently increments
// warnings but always calls emitAsciiPageFooter(..., true). That "true" is
// misleading, but changing it could alter output semantics; left as-is.

void playbackTask() {

  if ((playbackPageLimit > 0 && playbackPage >= playbackPageLimit) || (playbackPage >= currentPage)) {

    Serial.println();
    Serial.println("Dump summary:");
    Serial.print("  Pages processed: ");
    Serial.println(playbackPagesSeen);
    Serial.print("  CRC warnings:   ");
    Serial.println(playbackCrcWarnings);
    Serial.println();

    emitEvent("# Dump complete");

    mode = MODE_IDLE;
    printPrompt();
    return;
  }

  if (!playbackPageLoaded) {

    const uint32_t addr = playbackPage * FLASH_PAGE_SIZE;
    flash.readData(addr, playbackPageBuf, FLASH_PAGE_SIZE);

    const uint16_t footerOffset = FLASH_PAGE_SIZE - sizeof(PageFooter);
    memcpy(&playbackFooter,
           playbackPageBuf + footerOffset,
           sizeof(PageFooter));

    if (playbackFooter.magic != PAGE_MAGIC || playbackFooter.validFrames > FRAMES_PER_PAGE) {
      playbackPage++;
      playbackPageLoaded = false;
      return;
    }

    const uint16_t usedBytes = playbackFooter.validFrames * sizeof(Frame20);
    const uint16_t crcLen = usedBytes + offsetof(PageFooter, crc16);

    if (crc16_ccitt(playbackPageBuf, crcLen) != playbackFooter.crc16) {
      playbackCrcWarnings++;
    }

    if (playbackFormat == PLAYBACK_ASCII) {
      emitAsciiPageFooter(playbackPage, playbackFooter, true);
    } else {
      emitBinaryPageFooter(playbackFooter);
    }

    playbackFrameIndex = 0;
    playbackPageLoaded = true;
    playbackPagesSeen++;
    return;
  }

  if (playbackFrameIndex < playbackFooter.validFrames) {

    Frame20 &f = playbackFrames[playbackFrameIndex];
    const uint32_t id = playbackFooter.firstFrameID + playbackFrameIndex;

    if (playbackFormat == PLAYBACK_ASCII) {

      char line[96];
      snprintf(line, sizeof(line),
               "%lu %d %d %d %d %d %d %d %d %d %d",
               (unsigned long)id,
               f.q0, f.q1, f.q2, f.q3,
               f.ax, f.ay, f.az,
               f.mx, f.my, f.mz);

      Serial.println(line);
      if (bleUartEnabled && bleConnected && bleuart.notifyEnabled()) {
        bleuart.println(line);
      }

    } else {

      uint8_t pkt[24];
      pkt[0] = 0x55;
      pkt[1] = 0xAA;
      pkt[2] = sizeof(Frame20);
      pkt[3] = 0x00;

      memcpy(&pkt[4], &f, sizeof(Frame20));

      Serial.write(pkt, sizeof(pkt));
      if (bleUartEnabled && bleConnected && bleuart.notifyEnabled()) {
        bleuart.write(pkt, sizeof(pkt));
      }
    }

    playbackFrameIndex++;
    return;
  }

  playbackPage++;
  playbackPageLoaded = false;
}

// =============================================================================
// RECORDING
// =============================================================================

void startNewRecordingSession() {

  emitEvent("# Starting recording session (append)");

  frameIndexInPage = 0;
  recordPageLimit = 0;
  recordStartPage = currentPage;

  playbackPage = 0;
  playbackFrameIndex = 0;
  playbackPageLoaded = false;

  memset(pageFrames, 0, sizeof(pageFrames));

  myICM.resetFIFO();
  myICM.resetDMP();

  mode = MODE_RECORDING;

  emitEvent("# Recording started (append mode)");
}

// =============================================================================
// PAGE FOOTER EMISSION
// =============================================================================

void emitAsciiPageFooter(uint32_t page,
                         const PageFooter &f,
                         bool crcOk) {

  char line[128];
  snprintf(line, sizeof(line),
           "@PAGE %lu %u %lu %lu 0x%04X %s",
           (unsigned long)page,
           f.validFrames,
           (unsigned long)f.firstFrameID,
           (unsigned long)f.pageStartMs,
           f.crc16,
           crcOk ? "OK" : "BAD");

  Serial.println(line);
  if (bleUartEnabled && bleConnected && bleuart.notifyEnabled()) {
    bleuart.println(line);
  }
}

void emitBinaryPageFooter(const PageFooter &f) {

  uint8_t pkt[4 + sizeof(PageFooter)];
  pkt[0] = 0x56;
  pkt[1] = 0xAA;
  pkt[2] = sizeof(PageFooter);
  pkt[3] = 0x00;

  memcpy(&pkt[4], &f, sizeof(PageFooter));

  Serial.write(pkt, sizeof(pkt));
  if (bleUartEnabled && bleConnected && bleuart.notifyEnabled()) {
    bleuart.write(pkt, sizeof(pkt));
  }
}
